---
description: Open Wispr Video, the voice-first video editor (record, caption, edit by talking)
argument-hint: "[what you want to make, or an edit to apply]"
---
Use the wispr-video tools.

1. Call `video_open` (it starts the editor at http://127.0.0.1:4380 and opens it in the browser).
2. If $ARGUMENTS describes a new video (a topic or a script), call `video_new` with a title and, if they gave
   one, the script, then `video_open` again so the editor shows it.
3. If $ARGUMENTS is an edit ("cut the pauses", "captions bigger"), follow the wispr-video skill: `video_get`,
   then `video_edit`, then check one frame with `video_still`.
4. Otherwise tell them in one line: record in the Record tab (the teleprompter follows your voice), then
   say edits here or in the box under the preview.
