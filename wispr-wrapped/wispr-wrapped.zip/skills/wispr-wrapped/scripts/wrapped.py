#!/usr/bin/env python3
"""Wispr Wrapped, on your Mac.

Reads your Wispr Flow history (~/Library/Application Support/Wispr Flow/flow.sqlite, read-only copy), and, if
you use Claude Code, matches each dictation to the Claude Code session it went into. Builds a swipeable Wrapped
(a year in voice, plus one project) as a local HTML page, and every card as a 1080x1920 PNG via headless Chrome.
Nothing is uploaded: the only network requests are the page's Google Fonts.

  python3 wrapped.py                    # year + your most-talked-to project, open the page
  python3 wrapped.py --project relay    # pick the project (substring of its folder)
  python3 wrapped.py --stats            # print the numbers as JSON, build nothing
"""
import argparse, base64, bisect, collections, datetime as dt, glob, json, os, re, shutil, sqlite3, statistics, subprocess, sys, tempfile

HOME = os.path.expanduser('~')
FLOW = os.path.join(HOME, 'Library/Application Support/Wispr Flow/flow.sqlite')
PAGE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'page')
TYPE_WPM = 40  # an average typist; every "time saved" is labelled as an estimate
FILLERS = ['you know', 'i think', 'like', 'so', 'basically', 'actually', 'literally', 'sort of', 'kind of', 'i mean', 'just', 'also', 'okay', 'right']
UMS = ['um', 'uh', 'umm', 'uhh', 'hmm', 'er', 'erm']
BROWSERS = ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Chromium.app/Contents/MacOS/Chromium',
            '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge']
NOT_ROOTS = {'documents', 'projects', 'desktop', 'developer', 'code', 'src', 'repos', 'github', 'dev', 'work', 'sites'}

norm = lambda s: re.sub(r'\W+', ' ', (s or '').lower()).strip()
WORDS = lambda s: re.findall(r"[a-z][a-z'’]*", (s or '').lower())
nf = lambda n: f'{round(n):,}'
pct = lambda a, b: round(100 * a / b) if b else 0


def die(msg):
    print(json.dumps({'ok': False, 'error': msg}))
    sys.exit(1)


# ------------------------------------------------------------------ Flow history
def load_flow(path):
    if not os.path.exists(path):
        die('No Wispr Flow history on this Mac (looked for ' + path + '). Is Flow installed and have you dictated with it?')
    # read-only, in place: the file is ~200 MB of audio blobs, and only a few text columns are read.
    # If Flow holds a lock that a read-only handle can't get past, fall back to a temp copy.
    tmp = None
    try:
        dst = sqlite3.connect(f'file:{path}?mode=ro', uri=True)
        dst.execute('select count(*) from History').fetchone()
    except sqlite3.Error:
        tmp = tempfile.mkdtemp(prefix='wrapped-')
        src = sqlite3.connect(f'file:{path}?mode=ro', uri=True)
        dst = sqlite3.connect(os.path.join(tmp, 'flow.sqlite'))
        src.backup(dst); src.close()
    cols = {r[1] for r in dst.execute('pragma table_info(History)')}
    pick = lambda c, alt='NULL': c if c in cols else alt
    q = f"""select {pick('asrText')}, coalesce({pick('editedText')}, {pick('pastedText')}, {pick('formattedText')}), timestamp, {pick('app', "''")},
            coalesce({pick('speechDuration')}, {pick('duration')}, 0), numWords, {pick('timezoneOffsetMinutes')}
            from History where numWords > 0 and coalesce({pick('isArchived', '0')}, 0) = 0 order by timestamp"""
    rows = []
    for asr, text, ts, app, secs, n, tz in dst.execute(q):
        t = parse_ts(ts)
        if not t:
            continue
        local = t - dt.timedelta(minutes=tz) if tz is not None else t.astimezone()
        rows.append(dict(asr=asr or '', text=text or asr or '', utc=t, at=local.replace(tzinfo=None), app=app or '', secs=float(secs or 0), n=int(n)))
    dst.close()
    if tmp:
        shutil.rmtree(tmp, ignore_errors=True)
    return rows


def parse_ts(ts):
    if isinstance(ts, (int, float)):
        return dt.datetime.fromtimestamp(ts / (1000 if ts > 1e11 else 1), dt.timezone.utc)
    s = str(ts or '').strip().replace(' +00:00', '+00:00').replace('Z', '+00:00')
    try:
        t = dt.datetime.fromisoformat(s)
        return t if t.tzinfo else t.replace(tzinfo=dt.timezone.utc)
    except ValueError:
        return None


_app_names = {}
def app_name(bundle):
    if bundle in _app_names:
        return _app_names[bundle]
    name = None
    if bundle:
        try:
            out = subprocess.run(['mdfind', f'kMDItemCFBundleIdentifier == "{bundle}"'], capture_output=True, text=True, timeout=5).stdout.split('\n')[0]
            if out.endswith('.app'):
                name = os.path.basename(out)[:-4]
        except Exception:
            pass
    name = name or {'': 'Unknown app'}.get(bundle) or bundle.split('.')[-1].replace('-', ' ').title()
    name = {'Wispr Flow': 'Flow itself', 'Google Chrome': 'Chrome', 'UserNotificationCenter': 'Notifications', 'Microsoft Edge': 'Edge', 'Brave Browser': 'Brave'}.get(name, name)
    _app_names[bundle] = name
    return name


# ------------------------------------------------------------------ Claude Code sessions
def project_root(cwd):
    cwd = re.split(r'/\.claude/worktrees/', cwd or '')[0].rstrip('/')
    return cwd


def load_claude(since):
    """User prompts from Claude Code transcripts since `since` (UTC), with the project folder each went to."""
    msgs, tools, sessions = [], collections.Counter(), collections.defaultdict(set)
    cutoff = since.timestamp() - 86400
    for f in glob.glob(os.path.join(HOME, '.claude/projects/*/*.jsonl')):
        try:
            if os.path.getmtime(f) < cutoff:
                continue
            fh = open(f, 'rb')
        except OSError:
            continue
        root = None
        with fh:
            for line in fh:
                # most bytes are tool results and file dumps: skip those lines before parsing any JSON
                if b'"tool_use_id"' in line or (b'"type":"user"' not in line and b'"name":"Bash"' not in line):
                    continue
                try:
                    o = json.loads(line)
                except ValueError:
                    continue
                root = project_root(o.get('cwd')) or root
                if o.get('type') == 'assistant':
                    for x in (o.get('message') or {}).get('content') or []:
                        if isinstance(x, dict) and x.get('type') == 'tool_use' and x.get('name') == 'Bash' and root:
                            tools[root] += 1
                    continue
                if o.get('type') != 'user' or o.get('isMeta') or o.get('isSidechain'):
                    continue
                c = (o.get('message') or {}).get('content')
                if isinstance(c, list):
                    if any(isinstance(x, dict) and x.get('type') == 'tool_result' for x in c):
                        continue
                    c = ' '.join(x.get('text', '') for x in c if isinstance(x, dict) and x.get('type') == 'text')
                if not isinstance(c, str) or not c.strip() or not root:
                    continue
                t = parse_ts(o.get('timestamp'))
                if not t:
                    continue
                human = is_human(c)
                msgs.append(dict(t=t, root=root, text=c, norm=norm(c[:6000]), human=human, f=f))
                if human:
                    sessions[root].add(f)
    # fold sub-folders into their project (…/portfolio/site → …/portfolio), never into home or ~/Documents
    roots = sorted({m['root'] for m in msgs}, key=len)
    parent = {}
    for r in roots:
        parent[r] = r
        for p in roots:
            if p != r and r.startswith(p + '/') and p != HOME and len(p) > len(HOME) and os.path.basename(p).lower() not in NOT_ROOTS:
                parent[r] = parent[p]
                break
    for m in msgs:
        m['root'] = parent[m['root']]
    tools2, sess2 = collections.Counter(), collections.defaultdict(set)
    for r, k in tools.items():
        tools2[parent.get(r, r)] += k
    for r, s in sessions.items():
        sess2[parent.get(r, r)] |= s
    msgs.sort(key=lambda m: m['t'])
    return msgs, tools2, sess2


BOT = re.compile(r'^(<|\[Request interrupted|Caveat:|Base directory for this skill|The app was quit)|Background \(from the session|side-sessions-event|'
                 r'Review this change for|^Task:|Shared notes folder', re.M)
def is_human(text):
    return not BOT.search(text[:3000]) and len(text.split()) < 700


def match(rows, msgs):
    """Each dictation → the Claude Code prompt it was pasted into (by text, within 30 min after it)."""
    times = [m['t'] for m in msgs]
    for r in rows:
        r['root'] = None
        key = norm(r['text'])[:50]
        if len(key) < 15:
            continue
        lo = bisect.bisect_left(times, r['utc'] - dt.timedelta(minutes=2))
        hi = bisect.bisect_right(times, r['utc'] + dt.timedelta(minutes=30))
        for m in msgs[lo:hi]:
            if key in m['norm']:
                r['root'] = m['root']; m['dictated'] = True
                break


# ------------------------------------------------------------------ the numbers
def count(text, phrase):
    return len(re.findall(r"(?<![a-z'])" + re.escape(phrase) + r"(?![a-z'])", text))


def voice(rows):
    w = sum(r['n'] for r in rows)
    secs = sum(r['secs'] for r in rows)
    wpms = sorted(r['n'] / (r['secs'] / 60) for r in rows if r['secs'] > 8)
    hours = [0] * 24
    for r in rows:
        hours[r['at'].hour] += r['n']
    longest = max(rows, key=lambda r: r['n'])
    asr = ' '.join(r['asr'].lower() for r in rows)
    fin = ' '.join(r['text'].lower() for r in rows)
    fills = sorted(((f, count(asr, f), count(fin, f)) for f in FILLERS), key=lambda x: -x[1])
    ums = sum(count(asr, u) for u in UMS)
    apps = collections.Counter()
    for r in rows:
        apps[app_name(r['app'])] += r['n']
    first, last = rows[0]['at'], rows[-1]['at']
    return dict(n=len(rows), words=w, secs=secs, wpm=round(statistics.median(wpms)) if wpms else 0, wpm_max=round(min(300, wpms[-1])) if wpms else 0,
                hours=hours, peak=max(range(24), key=lambda h: hours[h]), night=sum(hours[:6]), longest=longest, fills=[f for f in fills if f[1]],
                ums=ums, removed=max(0, len(WORDS(asr)) - len(WORDS(fin))), apps=apps.most_common(), first=first, last=last,
                days=(last.date() - first.date()).days + 1, median=round(statistics.median([r['n'] for r in rows])))


def typing(prompts, dictated_words):
    """Typos in what you typed to Claude: words not in the Mac's dictionary and not something Flow ever spelt for you."""
    try:
        dic = {w.strip().lower() for w in open('/usr/share/dict/words')}
    except OSError:
        dic = set()
    ok = lambda w: (len(w) < 4 or w in dic or w.rstrip('s') in dic or w in dictated_words or w.endswith(('ed', 'ing', 'ly', 'er', 'es', "n't"))
                    or "'" in w or "’" in w or re.search(r'(.)\1\1', w))
    typos, per = collections.Counter(), []
    words = 0
    for p in prompts:
        raw = re.findall(r"[A-Za-z][A-Za-z'’]*", re.sub(r'https?://\S+|`[^`]*`|\S+\.\w{2,4}\b|\S*/\S*', ' ', p['text']))
        words += len(raw)
        bad = [w.lower() for w in raw if not w[0].isupper() and not ok(w.lower())]
        typos.update(bad); per.append(bad)
    # a word you typed 3+ times is a name you use (a product, a tool), not a slip
    typos = collections.Counter({w: k for w, k in typos.items() if k < 3})
    hit = sum(1 for bad in per if any(w in typos for w in bad))
    stretch = collections.Counter(w for p in prompts for w in WORDS(p['text']) if re.search(r'([a-z])\1\1', w) and len(w) > 3)
    return dict(words=words, typos=sum(typos.values()), examples=[w for w, _ in typos.most_common(12)], prompts_hit=hit, stretched=[w for w, _ in stretch.most_common(2)])


def mood(texts):
    t = ' '.join(x.lower() for x in texts)
    c = lambda p: len(re.findall(p, t))
    m = dict(q=t.count('?'), no=c(r'\bno\b'), still=c(r'\bstill\b'), again=c(r'\bagain\b'), why=c(r'\bwhy\b'), bro=c(r'\bbro+\b'),
             wtf=c(r'\b(wtf|ugh+|argh+|ffs)\b'), pos=c(r'\b(love|perfect|nice|great|yay+|awesome|amazing|cool)\b'))
    neg = m['no'] + m['still'] + m['again'] + m['wtf']
    m['label'] = 'Spicy' if neg > 3 * max(1, m['pos']) else 'Calm-ish' if neg > m['pos'] else 'Zen'
    low = [x.strip() for x in texts if re.search(r"not working|isn'?t working|doesn'?t work|still|wrong|broken|why is", x.lower()) and 3 <= len(x.split()) <= 12]
    m['quote'] = min(low, key=len) if low else None
    return m


def git_commits(root, since, until):
    n = 0
    for d in [root] + [os.path.join(root, x) for x in (os.listdir(root) if os.path.isdir(root) else [])]:
        if os.path.isdir(os.path.join(d, '.git')):
            try:
                out = subprocess.run(['git', '-C', d, 'rev-list', '--count', f'--since={since:%Y-%m-%d} 00:00', f'--until={until:%Y-%m-%d} 23:59', 'HEAD'],
                                     capture_output=True, text=True, timeout=10).stdout.strip()
                n += int(out or 0)
            except Exception:
                pass
    return n


# ------------------------------------------------------------------ copy
def hm(mins):
    mins = max(0, round(mins))
    return f'{mins // 60}h {mins % 60:02d}m' if mins >= 60 else f'{mins} min'


def hour_label(h):
    return {0: 'midnight', 12: 'noon'}.get(h, f'{h % 12}{"am" if h < 12 else "pm"}')


def when(dtm):
    return f'{dtm:%A}, {hour_label(dtm.hour) if dtm.minute == 0 else f"{dtm.hour % 12 or 12}:{dtm.minute:02d}" + ("am" if dtm.hour < 12 else "pm")}'


def opening(text, k=8):
    first = re.split(r'(?<=[.!?])\s', text.strip())[0]
    w = first.split()
    return '“' + ' '.join(w[:k]).rstrip(',;:') + ('…”' if len(w) > k else '”')


def personality(v, said_share=None, project=False):
    night = v['night'] / max(1, v['words'])
    fill_rate = sum(f[1] for f in v['fills']) / max(1, v['words'])
    if night > 0.5:
        return ('The 4am Director', 'Pitches the whole scene out loud in the dark, then types three words to approve it.') if project else \
               ('The Night-Shift Talker', 'Does the best thinking after midnight, out loud.')
    if v['median'] > 60:
        return 'The Long-Take Talker', 'Doesn’t do quick notes. Every dictation is a voice memo with a plan in it.'
    if fill_rate > 0.06:
        return 'The Thinker-Out-Loud', 'Finds the point by talking towards it. Flow tidies the path.'
    if v['wpm'] > 165:
        return 'The Speed Talker', 'Faster than anyone types. By a lot.'
    if said_share and said_share > 70:
        return 'The Director', 'Says what to build, lets Claude build it.'
    return 'The Straight Shooter', 'Short, clean, no detours. Rare.'


def fill_card(v, bg, scope):
    if not v['fills']:
        return dict(id='filler', bg=bg, k='Fillers', big='0', unit='ums, likes or you-knows', p='Not one. Suspiciously clean.')
    f, said, kept = v['fills'][0]
    rest = [[x[0], x[1]] for x in v['fills'][1:7]]
    p = f'Flow kept {nf(kept)} of them.' if kept < said else 'Flow kept them all: they meant something.'
    if v['ums']:
        p += f' It also cut all {nf(v["ums"])} ums and uhs'
        p += f', so {scope} got {nf(v["removed"])} fewer words of you thinking.' if v['removed'] else '.'
    return dict(id='filler', bg=bg, k='Most-said phrase', big=f'“{f}”', serif=True, unit=f'{nf(said)} times', p=p, viz=dict(type='list', items=rest) if rest else None)


def saved_card(v, words, bg, extra=''):
    type_min, talk_min = words / TYPE_WPM, v['secs'] / 60 or words / max(1, v['wpm'] or 130)
    return dict(id='saved', bg=bg, k='Time saved vs typing', big=hm(type_min - talk_min), unit='back, roughly',
                p=f'{hm(talk_min)} of talking. Typing the same {nf(words)} words at {TYPE_WPM} words a minute would take about {hm(type_min)}.{extra}',
                note=f'Estimate: {TYPE_WPM} wpm is an average typist. You talked at a median {v["wpm"]} wpm, {v["wpm_max"]} at your fastest.'), type_min - talk_min


def longest_card(v, bg, where):
    L = v['longest']
    return dict(id='longest', bg=bg, k='Longest single take', big=L['n'], unit=f'words in {int(L["secs"] // 60)} min {int(L["secs"] % 60)} s',
                p=f'{when(L["at"])}. Your longest single dictation{where}, in one go.', viz=dict(type='quote', text=opening(L['text']), by='how it started'))


def night_card(v, bg, where):
    h = v['peak']; share = pct(v['night'], v['words'])
    p = f'{share}% of your words{where} came before 6am.' if share >= 30 else f'Your busiest hour{where}. {pct(v["hours"][h], v["words"])}% of your words landed in it.'
    return dict(id='night', bg=bg, k='Peak hour', big=hour_label(h), serif=True, unit=f'{nf(v["hours"][h])} words between {hour_label(h)} and {hour_label((h + 1) % 24)}', p=p,
                viz=dict(type='hours', items=v['hours']))


def year_story(rows, name, year):
    v = voice(rows)
    since = f'{v["first"]:%-d %b}'
    fresh = v['first'].month > 1 or v['first'].day > 14
    saved, back = saved_card(v, v['words'], 'fathom')
    ty = personality(v)
    cards = [
        dict(id='intro', bg='lumen', k=f'{year} Wrapped' + (' · so far' if fresh else ''), big=f'{v["days"]} days' if fresh else str(year), serif=True,
             unit='of Flow, wrapped' + (' early' if fresh else ''), p=(f'Your Flow history starts on {since}. ' if fresh else '') + f'{nf(v["n"])} dictations later, this is your year in voice.',
             viz=dict(type='wave')),
        dict(id='words', bg='dawn', k='Words dictated', big=v['words'], unit=f'words in {nf(v["n"])} dictations', p=f'About {nf(v["words"] / 250)} pages, said in {hm(v["secs"] / 60)} of actual talking.'),
        saved,
    ]
    if v['apps']:
        top, tw = v['apps'][0]
        cards.append(dict(id='apps', bg='signal', k='Where you said it', big=top, serif=True, unit=f'{pct(tw, v["words"])}% of your words',
                          p='Flow works in any text box. This one got the most of you.' if len(v['apps']) > 1 else 'Every word went to one app.',
                          viz=dict(type='list', items=[[a, w] for a, w in v['apps'][:5] if a != 'Unknown app' and w >= v['words'] * 0.001])))
    cards += [longest_card(v, 'glow', ''), fill_card(v, 'lumen', 'your apps'), night_card(v, 'vast', '')]
    if v['days'] < 300:
        per_year = v['words'] / v['days'] * 365
        cards.append(dict(id='pace', bg='mint', k='At this pace', big=f'~{nf(per_year / 1000)}k' if per_year >= 10000 else nf(per_year), serif=True, unit='words a year',
                          p=f'That’s about {max(1, round(per_year / 90000))} novel{"s" if per_year >= 135000 else ""}, said out loud.', note=f'Estimate: straight-line from {v["days"]} days. It won’t hold. Probably.'))
    cards.append(dict(id='type', bg='flare', k='Voice personality', big=ty[0], serif=True, unit='', p=ty[1],
                      viz=dict(type='stats', items=[['Median take', f'{v["median"]} words'], ['Longest', f'{nf(v["longest"]["n"])} words'], ['Talking speed', f'{v["wpm"]} wpm'], ['Apps', str(len(v['apps']))]])))
    fv = v['fills'][0] if v['fills'] else None
    return dict(tab='Year', title=f'{year} Wrapped', who=f'{name} · every app', src=f'Your Wispr Flow history on this Mac, {since} – {v["last"]:%-d %b %Y}. Read here, never uploaded.',
                cards=cards, share=dict(k=f'My {year} in voice' + (', so far' if fresh else ''), big=nf(v['words']), unit='words, spoken',
                tiles=[['Time back', '~' + hm(back), 'fathom'], ['Top app', f'{v["apps"][0][0]}, {pct(v["apps"][0][1], v["words"])}%' if v['apps'] else '–', 'signal'],
                       ['Said it', f'“{fv[0]}” ×{nf(fv[1])}' if fv else 'no fillers', 'glow'], ['I am', ty[0], 'vast']])), v


def project_story(root, rows, msgs, tools, sessions, name):
    v = voice(rows)
    pname = os.path.basename(root)
    prompts = [m for m in msgs if m['root'] == root and m['human']]
    typed = [m for m in prompts if not m.get('dictated')]
    dictated_vocab = {w for r in rows for w in WORDS(r['text'])}
    tp = typing(typed, dictated_vocab)
    said_share = pct(v['words'], v['words'] + tp['words'])
    d1 = min([v['first']] + [m['t'].astimezone().replace(tzinfo=None) for m in prompts])
    d2 = max([v['last']] + [m['t'].astimezone().replace(tzinfo=None) for m in prompts])
    days = (d2.date() - d1.date()).days + 1
    commits = git_commits(root, d1, d2)
    md = mood([m['text'] for m in prompts])
    ty = personality(v, said_share, project=True)
    saved, back = saved_card(v, v['words'], 'fathom')
    bits = [f'{days} day{"s" if days > 1 else ""}'] + ([f'{nf(commits)} commits'] if commits else []) + [f'{nf(v["n"])} things said out loud']
    cards = [
        dict(id='intro', bg='lumen', k=f'Project Wrapped · {d1:%-d %b} – {d2:%-d %b}', big=pname, serif=True, unit='built by talking' if said_share >= 50 else 'built by typing, mostly',
             p=', '.join(bits[:-1]) + ' and ' + bits[-1] + '. Here’s what the talking looked like.', viz=dict(type='wave')),
        dict(id='words', bg='dawn', k='Words said to this project', big=v['words'], unit='words, spoken',
             p=f'{said_share}% of everything you told Claude here, you said out loud. The other {100 - said_share}% you typed.',
             viz=dict(type='split', items=[['Said', v['words']], ['Typed', max(1, tp['words'])]])),
        saved, longest_card(v, 'signal', ' into this project'), fill_card(v, 'glow', 'Claude'),
    ]
    if tp['words'] >= 150 and tp['typos'] >= 3:
        cards.append(dict(id='typos', bg='lumen', k='Typed vs said', big=tp['typos'], unit=f'typos in {nf(tp["words"])} typed words',
                          p=f'About one every {round(tp["words"] / tp["typos"])} words, in {tp["prompts_hit"]} of {len(typed)} typed prompts. The prompts you said, Flow spelt for you.',
                          viz=dict(type='chips', items=tp['examples'] + tp['stretched'])))
    if len(prompts) >= 10:
        extra = ''.join(f' One “{w}”.' for w in tp['stretched'])
        cards.append(dict(id='mood', bg='mint', k='Frustration, measured', big=md['label'], serif=True, unit='mostly',
                          p=f'{md["q"]} questions, {md["no"]} no’s, {md["still"]} still’s and {md["bro"]} bro’s, against {md["pos"]} yays and loves.{extra}',
                          viz=dict(type='quote', text=f'“{md["quote"]}”', by='the low point') if md['quote'] else None))
    cards.append(night_card(v, 'vast', ' to this project'))
    shortest = min((m['text'].strip() for m in typed if 0 < len(m['text'].split()) <= 3 and re.search(r'[a-z]{2}', m['text'].lower())), key=len, default=None)
    stats = [['Claude sessions', nf(len(sessions.get(root, ())))], ['Commands Claude ran', nf(tools.get(root, 0))]]
    stats += [['Commits', nf(commits)]] if commits else [['Prompts', nf(len(prompts))]]
    stats += [['Shortest typed prompt', f'“{shortest[:18]}”']] if shortest else [['Talking speed', f'{v["wpm"]} wpm']]
    cards.append(dict(id='type', bg='flare', k='Voice personality', big=ty[0], serif=True, unit='', p=ty[1], viz=dict(type='stats', items=stats)))
    fv = v['fills'][0] if v['fills'] else None
    story = dict(tab='Project', title='Project Wrapped', who=f'{name} · {pname}',
                 src=f'Your Wispr Flow history, matched to the Claude Code sessions in {pname}, {d1:%-d %b} – {d2:%-d %b %Y}. Read here, never uploaded.',
                 cards=cards, share=dict(k='My project, wrapped', big=nf(v['words']), unit=f'words said to {pname}',
                 tiles=[['Time back', '~' + hm(back), 'fathom'], ['Peak hour', hour_label(v['peak']), 'vast'],
                        ['Said it', f'“{fv[0]}” ×{nf(fv[1])}' if fv else 'no fillers', 'glow'], ['I am', ty[0], 'signal']]))
    return story, dict(project=pname, words=v['words'], said_share=said_share, typos=tp['typos'], typed_words=tp['words'], commits=commits, sessions=len(sessions.get(root, ())), peak=hour_label(v['peak']), type=ty[0])


# ------------------------------------------------------------------ the page + PNGs
def build_page(stories, out):
    os.makedirs(out, exist_ok=True)
    tpl = open(os.path.join(PAGE, 'template.html')).read()
    data = 'window.WW_DATA = ' + json.dumps(dict(C=dict(lumen='#ffffeb', paper='#fffdf9', vast='#1a1a1a', mute='#5d5d52', fathom='#034f46', dawn='#f0d7ff',
                                                     signal='#ffbcf2', glow='#ffa946', flare='#ff6c4c', pulse='#7f1c34', mint='#cfe8dc'), STORIES=stories), ensure_ascii=False) + ';'
    data += '\nwindow.WW_CONFIG = { yours: false, link: false, foot: ["Wispr Wrapped · made on my Mac", "sameep.ai/wispr-wrapped"] };'
    safe = lambda s: s.replace('</script', '<\\/script')
    page = tpl.replace('/*__CSS__*/', open(os.path.join(PAGE, 'style.css')).read()).replace('/*__DATA__*/', safe(data)).replace('/*__APP__*/', safe(open(os.path.join(PAGE, 'app.js')).read()))
    path = os.path.join(out, 'index.html')
    open(path, 'w').write(page)
    return path


def export_pngs(page, stories, out):
    """One headless Chrome run draws every card on the page's own canvas and hands the PNGs back through the DOM."""
    exe = next((b for b in BROWSERS if os.path.exists(b)), None)
    if not exe:
        return None, 'No Chrome, Chromium, Brave or Edge found, so no PNGs. Open the page and use “Save this card” instead.'
    cards = os.path.join(out, 'cards')
    os.makedirs(cards, exist_ok=True)
    prof = tempfile.mkdtemp(prefix='wrapped-chrome-')
    try:
        dom = subprocess.run([exe, '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check', '--mute-audio', f'--user-data-dir={prof}',
                              '--virtual-time-budget=60000', '--dump-dom', f'file://{page}?png=all'], capture_output=True, text=True, timeout=240).stdout
    except subprocess.TimeoutExpired:
        dom = ''
    finally:
        shutil.rmtree(prof, ignore_errors=True)
    want = sum(len(st['cards']) + 1 for st in stories.values())
    made = 0
    for mode, n, cid, b64 in re.findall(r'(\w+) (\d+) (\w+) data:image/png;base64,([A-Za-z0-9+/=]+)', dom):
        with open(os.path.join(cards, f'{mode}-{int(n):02d}-{cid}.png'), 'wb') as fh:
            fh.write(base64.b64decode(b64))
        made += 1
    if not made:
        return None, 'Couldn’t draw the PNGs with headless Chrome. Open the page and use “Save this card” instead.'
    return cards, None if made == want else f'{want - made} of {want} PNGs failed; use “Save this card” on the page for those.'


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--project', help='project folder (substring) for the Project Wrapped; default: the one you talked to most')
    ap.add_argument('--no-project', action='store_true', help='year only')
    ap.add_argument('--year', type=int, default=dt.date.today().year)
    ap.add_argument('--name', help='your name on the cards (default: your first name on this Mac)')
    ap.add_argument('--out', default=os.path.join(HOME, 'Wispr Wrapped'))
    ap.add_argument('--db', default=FLOW)
    ap.add_argument('--no-png', action='store_true')
    ap.add_argument('--no-open', action='store_true')
    ap.add_argument('--stats', action='store_true', help='print the numbers, build nothing')
    a = ap.parse_args()

    rows = [r for r in load_flow(a.db) if r['at'].year == a.year]
    if len(rows) < 5 or sum(r['n'] for r in rows) < 100:
        die(f'Only {len(rows)} dictations in {a.year} so far. Dictate a bit more with Flow, then run this again.')
    name = a.name
    if not name:
        try:
            name = subprocess.run(['id', '-F'], capture_output=True, text=True).stdout.strip().split(' ')[0]
        except Exception:
            name = ''
    name = name or 'You'

    stories, summary = {}, {}
    project = None
    if not a.no_project and os.path.isdir(os.path.join(HOME, '.claude/projects')):
        msgs, tools, sessions = load_claude(rows[0]['utc'])
        match(rows, msgs)
        by_root = collections.Counter()
        for r in rows:
            if r['root']:
                by_root[r['root']] += r['n']
        pick = [x for x in by_root if a.project.lower() in x.lower()] if a.project else [x for x, _ in by_root.most_common()]
        pick.sort(key=lambda x: -by_root[x])
        if pick and by_root[pick[0]] >= 100:
            project = pick[0]
            st, summary['project'] = project_story(project, [r for r in rows if r['root'] == project], msgs, tools, sessions, name)
            stories['project'] = st
        summary['projects_talked_into'] = len(by_root)
        if a.project and not project:
            summary['note'] = f'No project matching “{a.project}” has 100+ dictated words; built the year only.'
    st, v = year_story(rows, name, a.year)
    stories['year'] = st
    summary['year'] = dict(words=v['words'], dictations=v['n'], days=v['days'], wpm=v['wpm'], peak=hour_label(v['peak']),
                           top_filler=v['fills'][0][:2] if v['fills'] else None, top_app=v['apps'][0] if v['apps'] else None, longest=v['longest']['n'])
    if a.stats:
        print(json.dumps(dict(ok=True, **summary), indent=1, default=str))
        return
    out = os.path.expanduser(a.out)
    page = build_page(stories, out)
    cards, warn = (None, None) if a.no_png else export_pngs(page, stories, out)
    if not a.no_open:
        subprocess.run(['open', page])
    print(json.dumps(dict(ok=True, page=page, cards=cards, warning=warn, **summary), indent=1, default=str, ensure_ascii=False))


if __name__ == '__main__':
    main()
