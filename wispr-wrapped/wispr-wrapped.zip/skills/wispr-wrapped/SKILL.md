---
name: wispr-wrapped
description: Build the user's Wispr Wrapped, a Spotify-Wrapped-style story of their year in voice plus one project, from their own Wispr Flow history on this Mac (words, wpm, top fillers, longest take, apps, typos vs dictation, peak hour, time saved as an estimate). Outputs a local HTML page and 1080x1920 PNG cards; nothing is uploaded. Use for "/wispr-wrapped", "my Wispr Wrapped", "my Flow stats", "how much have I dictated", "wrap my project".
allowed-tools: Bash(python3:*), Bash(open:*)
---

# Wispr Wrapped

Everything runs on this Mac. The script reads a read-only copy of Wispr Flow's local history
(`~/Library/Application Support/Wispr Flow/flow.sqlite`) and, when Claude Code transcripts exist in
`~/.claude/projects`, matches each dictation to the project it was said into. It never sends data anywhere;
the page it writes only fetches its fonts.

## Run it

The script is `scripts/wrapped.py` in this skill's base directory (shown above as "Base directory for this skill").

1. If the user named a project ("wrap my relay project"), pass `--project <folder name or part of it>`.
   Otherwise pass nothing: it picks the project they talked to most. `--no-project` gives the year only.
2. Run it (takes 10–60 s, most of it drawing PNGs):

   ```sh
   python3 "<base directory>/scripts/wrapped.py" [--project NAME]
   ```

   It writes `~/Wispr Wrapped/index.html` and `~/Wispr Wrapped/cards/*.png`, opens the page, and prints JSON.
3. If the JSON has `"ok": false`, tell the user the `error` in one line (usually: Flow isn't installed, or
   there aren't enough dictations yet) and stop.

## Tell them

Keep it short and in their numbers, Wrapped-style. Say:

- the 3 or 4 best facts from the JSON (words, top filler and its count, peak hour, their personality type;
  for a project, the said-vs-typed share and the typo count are the fun ones),
- where the page and the PNG folder are (`cards`), and that every card is a 9:16 PNG ready for a story,
- any `warning` (for example, no Chrome means no PNGs: they can use "Save this card" on the page instead).

Time saved is an estimate (typing at 40 wpm vs their measured talking time); say "about" or "roughly".
Don't paste their transcripts back. Offer `--project <other>` if `projects_talked_into` is more than 1.

## Options

| Flag | Does |
| --- | --- |
| `--project NAME` | Project Wrapped for the Claude Code folder whose path contains NAME |
| `--no-project` | Year only |
| `--year 2026` | Another year |
| `--name Sam` | Name on the cards (default: first name on this Mac) |
| `--out DIR` | Write somewhere other than `~/Wispr Wrapped` |
| `--no-png` / `--no-open` | Skip the PNGs / don't open the page |
| `--stats` | Print the numbers only |
