# Wispr Wrapped

Your Wispr Flow year in voice, plus a Wrapped for the project you talked to most. Claude reads your own
Flow history on your Mac and builds a swipeable story and a 9:16 PNG of every card. Nothing gets uploaded.

Part of Wispr for Builders, Pack 1. By [Sameep Rehlan](https://sameep.ai).

## Run it

```sh
claude --plugin-url https://sameep.ai/wispr-wrapped/wispr-wrapped.zip "/wispr-wrapped"
```

Or, in a session that has it: `/wispr-wrapped`, `/wispr-wrapped relay` (a project), "wrap my year".

You get `~/Wispr Wrapped/index.html` and `~/Wispr Wrapped/cards/*.png`.

## What it counts

- **Year:** words dictated, time saved vs typing (an estimate: 40 wpm typing vs your real talking time), median
  and top wpm, top apps, longest take, most-said filler (and how many Flow cut), peak hour, a straight-line
  "at this pace" year, a voice personality.
- **Project:** each dictation is matched to the Claude Code prompt it went into (`~/.claude/projects`), so it
  adds said-vs-typed share, typos in what you typed, a frustration meter (no's, still's, bro's vs yays),
  Claude sessions, commands Claude ran and commits.

## Privacy

`scripts/wrapped.py` takes a read-only copy of `~/Library/Application Support/Wispr Flow/flow.sqlite` in a temp
folder, reads your Claude Code transcripts in place, and deletes the copy. It makes no network calls. The page
loads Google Fonts and nothing else. PNGs are drawn by headless Chrome (or Chromium, Brave, Edge) from that
local page.

Needs macOS, Python 3 (ships with Xcode command line tools) and Wispr Flow. Claude Code is optional for the
year; the project Wrapped needs it.

## Develop

The page renderer lives in the site (`portfolio/site/wispr-wrapped/app.js`, `style.css`, and the shared Wispr kit
`portfolio/site/wispr-kit/wispr.css`). `./build.sh` copies them into `skills/wispr-wrapped/page/`, zips the plugin and puts the zip next to the page for sameep.ai to serve.
